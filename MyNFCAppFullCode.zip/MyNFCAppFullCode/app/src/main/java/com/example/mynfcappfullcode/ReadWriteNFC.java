package com.example.mynfcappfullcode;

//androidx.appcompat.app.AppCompatActivity and android.os.Bundle are put in by default when basic
//activity selected when new project is created in Android Studio. All of the other imports were
//put in manually later during the making of the project.
//START
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import android.content.Intent;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.NfcEvent;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.nio.charset.Charset;
import java.util.ArrayList;
//END

//Unlike our MainActivity class which only used implement View.OnClickListener, this class
//also implements NfcAdapter.OnNdefPushCompleteCallback and NfcAdapter.CreateNdefMessageCallback.

//NfcAdapter.OnNdefPushCompleteCallback is a callback to be invoked when the system successfully
//delivers your NdefMessage to another device. This interface was deprecated in API level 29.
//File sharing can work using other technology like Bluetooth.

//NfcAdapter.CreateNdefMessageCallback is a callback to be invoked when another NFC device capable
//of NDEF push (Android Beam) is within range. This interface was deprecated in API level 29.
//File sharing can work using other technology like Bluetooth.
public class ReadWriteNFC extends AppCompatActivity implements View.OnClickListener,
        NfcAdapter.OnNdefPushCompleteCallback,
        NfcAdapter.CreateNdefMessageCallback{

    //Make a private NfcAdapter object and call it myNfcAdapter
    //1 LINE
    //***START***
    private NfcAdapter myNfcAdapter;
    //***FINISH***

    //The array lists to hold our messages
    private ArrayList<String> messagesSentArray = new ArrayList<>();
    private ArrayList<String> messagesReceivedArray = new ArrayList<>();

    //Creating Java equivalent objects for the widget in our activity main user interface which we created
    //in xml that we want to interact with (change) or give values to in some way.
    //START
    private EditText edtCreateMessage;
    private Button btnSendMessage;
    private Button btnReadMessage;
    private Button btnExit;
    private TextView txtLastSentMessage;
    private TextView txtReceivedMesssages;
    //FINISH

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_write_nfc);

        edtCreateMessage = findViewById(R.id.edtCreateMessage);
        btnSendMessage = findViewById(R.id.btnSendMessage);
        txtLastSentMessage = findViewById(R.id.txtLastSentMessage);
        btnReadMessage = findViewById(R.id.btnReadMessages);
        txtReceivedMesssages = findViewById(R.id.txtReceivedMessages);
        btnExit = findViewById(R.id.btnBack);

        //Check for available NFC Adapter and connect it to the NfcAdapter object we
        //create.
        //1 LINE
        //***START***
        myNfcAdapter = NfcAdapter.getDefaultAdapter(this);
        //***FINISH**

        //Use an if statement to check if your device has an NfcAdapter. If it does not
        //have one then a Toast pop up should appear saying "NFC is not available" and the
        //activity should close taking us back to the launch activity. This is the type of
        //action you might take in a real world app.
        //~4 LINES
        //***START***
        if (myNfcAdapter == null){
            Toast.makeText(this, "NFC is not available",
                    Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        //***FINISH***

        //This is setting the instructions of what to do when the button "Send Message" is pressed.
        //When we put "this" inside the brackets it is telling the system to use the main onClick
        //method for the onClickListener for this button. You only have one onClick that is not nested ie
        //the onClick is inside the setOnClickListener.
        //START
        btnSendMessage.setOnClickListener(this);
        //FINISH

        //This is setting the instructions of what to do when the button "Read Messages" is pressed.
        //We will not be putting any information inside this because we are only looking at generic
        //code but what actions you would take after data is received would depend on what
        btnReadMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        //This is setting the instructions of what to do when the button "Back" is pressed.
        //The instruction is just telling the system to close the activity and go back to
        //the previous activity (the launcher activity).
        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });

    }

    //This is setting the instructions of what to do when the button "Send Message" is pressed.
    //We will not be putting any information inside this because we are only looking at generic
    //code but what actions you would take after data is received would depend on what
    public void onClick(View view) {

    }

    //This method is triggered because in the AndroidManifest.xml of this application I put a line
    //inside the settings of the activity name .ReadWriteNFC that says 'android:launchmode="singleTask"'
    @Override
    public void onNewIntent(Intent intent) {
        //Make a call to super.onNewIntent and pass it the Intent that has been passed
        //to this method onNewIntent. We have android:launchMode="singleTask". This line
        //checks if an instance of this activity is already open and if it is, uses it instead
        //of opening another instance. This is related to the fact that in our AndroidManifest.xml
        //in the settings of our .ReadWrite activity we have android:launchmode="singleTask".
        //1 LINE
        //***START***
        super.onNewIntent(intent);
        //***FINISH***
        //Call our handleNfcIntent method and send it the intent that we received into onNewIntent.
        //1 LINE
        //***START***
        handleNfcIntent(intent);
        //***FINISH***
    }


    private void handleNfcIntent(Intent NfcIntent) {
        //Inside the brackets put the condition to check NfcAdapter.ACTION_NDEF_DISCOVERED equals
        //NfcIntent.getAction(). You are checking that there is an action in the intent that is
        //passed to this method (i.e. that it is not null)
        //1 LINE
        //***START***
        if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(NfcIntent.getAction())) {
            //***FINISH***
            //The Parcel class (and the corresponding Parcelable API for placing arbitrary objects
            //into a Parcel) is designed as a high-performance IPC transport. As such, it is not
            //appropriate to place any Parcel data in to persistent storage: changes in the underlying
            //implementation of any of the data in the Parcel can render older data unreadable. The
            //bulk of the Parcel API revolves around reading and writing data of various types.

            //If an activity starts because of an NFC intent, you can obtain information about the
            //scanned NFC tag from the intent. Intents can contain the following extras depending on
            //the tag that was scanned:
            //EXTRA_TAG (required): A Tag object representing the scanned tag.
            //EXTRA_NDEF_MESSAGES (optional): An array of NDEF messages parsed from the tag.
            //This extra is mandatory on ACTION_NDEF_DISCOVERED intents.
            //EXTRA_ID (optional): The low-level ID of the tag.
            //Get what is in Extra Ndef messages and give it to the Parcelable[] called receivedArray
            //1 LINE
            //***START***
            Parcelable[] receivedArray =
                    NfcIntent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
            //***FINISH***
            //Below we are checking that what we have just put into the Parcelable array we called
            //receivedArray.  If what is in there is not null (i.e. there is something in there)
            //then we delete what is currently inside the ArrayList<String> messagesReceived that
            //was created at the top of this class.  We then put the information just received into
            //that ArrayList<String>
            //Inside the brackets put the condition to check receivedArray is not null
            //1 LINE
            //***START***
            if(receivedArray != null) {
                //***FINISH***
                messagesReceivedArray.clear();
                NdefMessage receivedMessage = (NdefMessage) receivedArray[0];
                NdefRecord[] attachedRecords = receivedMessage.getRecords();
                for (NdefRecord record:attachedRecords) {
                    String string = new String(record.getPayload());
                    //Make sure we don't pass along our AAR (Android Application Record)
                    if (string.equals(getPackageName())) {
                        continue;
                    }
                    messagesReceivedArray.add(string);
                }
                //We have a pop up Toast message indicating how many messages (if their are any)
                Toast.makeText(this, "Received " + messagesReceivedArray.size() +
                        " Messages", Toast.LENGTH_LONG).show();
            }
            else {
                //Pop up Toast message indicating that the Parcel is blank if that is the case
                Toast.makeText(this, "Received Blank Parcel", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        handleNfcIntent(getIntent());
    }

    //This is called when the system detects that our NdefMessage was successfully sent. We have not
    //put any instructions into this method for this project.
    @Override
    public void onNdefPushComplete(NfcEvent event) {


    }

    @Override
    public NdefMessage createNdefMessage(NfcEvent event) {
        //This will be called when another NFC capable device is detected.
        if (messagesSentArray.size() == 0) {
            return null;
        }
        //We'll write the createRecords() method in just a moment
        NdefRecord[] recordsToAttach = createRecords();
        //When creating an NdefMessage we need to provide an NdefRecord[]
        return new NdefMessage(recordsToAttach);
    }

    public NdefRecord[] createRecords() {
        NdefRecord[] records = new NdefRecord[messagesSentArray.size()];

        for (int i = 0; i < messagesSentArray.size(); i++){
            byte[] payload = messagesSentArray.get(i).
                    getBytes(Charset.forName("UTF-8"));

            NdefRecord record = new NdefRecord(
                    NdefRecord.TNF_WELL_KNOWN,  //Our 3-bit Type name format
                    NdefRecord.RTD_TEXT,        //Description of our payload
                    new byte[0],                //The optional id for our Record
                    payload);                   //Our payload for the Record

            records[i] = record;
        }

        records[messagesSentArray.size()] =
                NdefRecord.createApplicationRecord(getPackageName());

        return records;
    }

}